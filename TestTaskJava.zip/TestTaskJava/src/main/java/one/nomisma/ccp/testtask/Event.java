package one.nomisma.ccp.testtask;

/**
 *
 * @author Minas
 */
public class Event {

    private final int eventId;
    private final long eventDateMs;

    public Event(int eventId, long eventDateMs) {
        this.eventId = eventId;
        this.eventDateMs = eventDateMs;
    }

    public long getEventDateMs() {
        return eventDateMs;
    }

    public int getEventId() {
        return eventId;
    }
}
