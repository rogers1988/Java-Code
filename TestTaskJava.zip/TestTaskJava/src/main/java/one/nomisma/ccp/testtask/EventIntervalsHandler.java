package one.nomisma.ccp.testtask;

import java.util.List;

/**
 * Implementation should be thread safe and ready to process tons of data.
 *
 * @author Minas
 */
public interface EventIntervalsHandler {

    /**
     * Registers event
     *
     * @param event
     */
    public void register(Event event);

    /**
     *
     * @param eventId
     * @return list of intervals by event id. List is ordered by hour from, list
     * is sorted according to natural order. Itervals are not crossing with each
     * other. If event is not registered yet, it returns empty list. Intervals
     * represent hours for registered events. Intervals are <b>merged<b>, so if
     * there were 2 events with the same id at hour 0 and at hour 1 it returns 1
     * interval [0;2)
     */
    public List<Interval> getRegisteredHours(int eventId);

    /**
     *
     * @param eventId
     * @param hourNo
     * @return interval for requested eventId that covers requested hourNo.
     * Interval should be <b>merged<b>(see getRegisteredHours for details). Null
     * if not not found.
     */
    public Interval getInterval(int eventId, int hourNo);

}
