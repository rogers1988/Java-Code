package one.nomisma.ccp.testtask;

/**
 * Interval is based on hours.<br/>
 * Hour - it is the difference, measured in hours, between the current time and
 * midnight, January 1, 1970 UTC.<br/>
 * Example#1 - 1970-01-02T01:00:00 - its hour 25. The Interval is [25;26)<br/>
 * Example#2 - 1970-01-01T00:59:59 - its hour 0. 1970-01-00T01:00:00 - its hour 1.
 * The Interval is [0;2)<br/>
 *
 * @author Minas
 */
public interface Interval {

    /**
     *
     * @return from hour of interval (inclusive)
     */
    public int getHourFrom();

    /**
     *
     * @return to hour of interval (exclusive)
     */
    public int getHourTo();

}
